## Chess functions test

Web page meant as a proof of concept of the functions available in [Chess Functions](https://github.com/sandy98/chess-functions)

Test page available at [this very site](https://chess-functions-test.stackblitz.io/)